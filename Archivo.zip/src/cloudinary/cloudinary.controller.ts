import { Controller, Post, UploadedFile, UseInterceptors, HttpStatus, HttpException } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { CloudinaryService } from './cloudinary.service';
import { ApiTags, ApiOperation, ApiResponse, ApiConsumes } from '@nestjs/swagger';
import { CloudinaryResponse } from './cloudinary-response';

@ApiTags('cloudinary')
@Controller('cloudinary')
export class CloudinaryController {
    constructor(private readonly cloudinaryService: CloudinaryService) { }

    @Post('upload')
    @ApiOperation({ summary: 'Upload a file to Cloudinary' })
    @ApiResponse({ status: 201, description: 'File successfully uploaded to Cloudinary.' })
    @ApiResponse({ status: 400, description: 'Invalid file or upload error.' })
    @ApiConsumes('multipart/form-data')
    @UseInterceptors(FileInterceptor('file'))
    async uploadFile(@UploadedFile() file: Express.Multer.File): Promise<CloudinaryResponse> {
        if (!file) {
            throw new HttpException('No file provided', HttpStatus.BAD_REQUEST);
        }

        try {
            return await this.cloudinaryService.uploadFile(file);
        } catch (error) {
            throw new HttpException(error.message, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}