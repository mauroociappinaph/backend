export class Entrepreneur {}
