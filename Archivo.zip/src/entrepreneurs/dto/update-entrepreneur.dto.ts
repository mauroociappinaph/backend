import { CreateEntrepreneurDTO } from './create-entrepreneur.dto';

export type UpdateEntrepreneurDto = Partial<CreateEntrepreneurDTO>