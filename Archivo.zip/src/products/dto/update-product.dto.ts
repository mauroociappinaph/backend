import { CreateProductDTO } from './create-product.dto';

export type UpdateProductDto = Partial<CreateProductDTO>