export { CORS } from './cors'

