-- AlterTable
ALTER TABLE "Entrepreneurs" ADD COLUMN "lastProductDelete" INTEGER;
