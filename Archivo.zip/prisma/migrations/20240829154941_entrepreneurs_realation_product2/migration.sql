-- AlterTable
ALTER TABLE "Entrepreneurs" ADD COLUMN "phoneNumber" TEXT;
ALTER TABLE "Entrepreneurs" ADD COLUMN "twitterHandle" TEXT;
ALTER TABLE "Entrepreneurs" ADD COLUMN "website" TEXT;
