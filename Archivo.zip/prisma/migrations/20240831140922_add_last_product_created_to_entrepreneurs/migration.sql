-- AlterTable
ALTER TABLE "Entrepreneurs" ADD COLUMN "lastProductCreated" INTEGER;
