-- AlterTable
ALTER TABLE "Entrepreneurs" ADD COLUMN "lastProductUpdated" INTEGER;
